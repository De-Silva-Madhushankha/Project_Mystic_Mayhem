package Characters.Mages;
import Characters.Character;

public abstract class Mage extends Character {
}
