package Characters.Archers;
import Characters.Character;
public abstract class Archer extends Character {}
