package Characters.Knights;
import Characters.Character;

public abstract class Knight extends Character {
}
