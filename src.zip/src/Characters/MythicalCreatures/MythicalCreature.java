package Characters.MythicalCreatures;
import Characters.Character;

public abstract class MythicalCreature extends Character {
}
