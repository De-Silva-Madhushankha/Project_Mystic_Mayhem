package Equipment.Artefacts;
import Equipment.Equipment;

public abstract class Artefact implements Equipment {
}
