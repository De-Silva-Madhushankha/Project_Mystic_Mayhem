package Equipment.Armour;
import Equipment.Equipment;

public abstract class Armour implements Equipment {
}
