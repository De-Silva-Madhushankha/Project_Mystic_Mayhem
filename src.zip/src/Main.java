import java.util.*;

import Characters.Character;
import Equipment.Equipment;

import Characters.Archers.*;
import Characters.Healers.*;
import Characters.Knights.*;
import Characters.Mages.*;
import Characters.MythicalCreatures.*;

import Equipment.Armour.*;
import Equipment.Artefacts.*;

import static java.lang.System.exit;

public class Main {
    static Set<String> usernames = new LinkedHashSet<>();
    static List<UserProfile> users = new ArrayList<>();
    public static void clearConsole() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (final Exception e) {
            e.printStackTrace();
        }
    }
    public static List<Character> getAttackPriority(List<Character> guild){

        List<Character> newGuild = new ArrayList<>(Collections.nCopies(5, null));
        for (Character c : guild){
            switch (c.getClass().getSuperclass().getSimpleName()){
                case "Healer" -> newGuild.set(0,c);
                case "Mage" -> newGuild.set(1,c);
                case "MythicalCreature" -> newGuild.set(2,c);
                case "Knight" -> newGuild.set(3,c);
                case "Archer" -> newGuild.set(4,c);
            }
        }
        return newGuild;
    }

    public static void selectHomeground(UserProfile user){
        Scanner scan = new Scanner(System.in);
        System.out.println("Home Ground");
        String homeGrounds = """
                        1 Hillcrest
                        2 Marshland
                        3 Desert
                        4 Arcane""";
        System.out.println(homeGrounds);
        System.out.print("Select your Home ground(1/2/3/4): ");
        int userHomeGround = scan.nextInt();
        boolean choice2 = true;
        while(choice2){
            if(userHomeGround<5 && userHomeGround>0){
                choice2 = false;
                switch (userHomeGround) {
                    case 1 -> user.setHomeground("Hillcrest");
                    case 2 -> user.setHomeground("Marshland");
                    case 3 -> user.setHomeground("Desert");
                    case 4 -> user.setHomeground("Arcane");
                }
            }
            else{
                System.out.println("You have entered an invalid number. Please enter a valid number");
                System.out.println("Home Ground");
                homeGrounds = """
                        1 Hillcrest
                        2 Marshland
                        3 Desert
                        4 Arcane""";
                System.out.println(homeGrounds);
                System.out.print("Select your Home ground(1/2/3/4): ");
                userHomeGround = scan.nextInt();
            }
        }
    }

    public static void combat(UserProfile player1, UserProfile player2){
        // player1 -> User
        // player2 -> Opponent

        String battleLocation = player1.getHomeground();
        String p1Name = player1.getName();
        String p2Name = player2.getName();

        // Set player1's Home ground for all characters
        for (Character c : player1.guild){
            c.setBattleGround(battleLocation);
        }
        for (Character c: player2.guild){
            c.setBattleGround(battleLocation);
        }


        // Battle
        for(int i =1; i<11;i++){

            // List attack priority order
            player1.guild = getAttackPriority(player1.guild);
            player2.guild = getAttackPriority(player2.guild);

            Character p1Hero = null;
            Character p2Hero = null;

            // find and select characters for this round
            double maxSpeed = 0; // tempValue
            for(Character c: player1.guild){
                if(maxSpeed <= c.getSpeed() && c.getHealth() > 0){
                    p1Hero = c;
                    maxSpeed = c.getSpeed();
                }
            }
            maxSpeed = 0;
            for(Character c: player2.guild){
                if(maxSpeed <= c.getSpeed() && c.getHealth() > 0){
                    p2Hero = c;
                    maxSpeed = c.getSpeed();
                }
            }

            assert p1Hero != null;
            assert p2Hero != null;

            String p1HeroName = p1Hero.getClass().getSimpleName();
            String p2HeroName = p2Hero.getClass().getSimpleName();

            //Battle status
            System.out.print("Turn "+i+": ");
            System.out.println(p1Name);
            System.out.print(p1Name+"'s "+p1HeroName + " attacks " +p2Name+"'s ");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            // player1 attack
            switch (battleLocation) {
                case "Hillcrest" -> {
                    if (p1Hero.getCharacterType() == "Highlander") {

                        //First attack
                        p1Hero.attack(player2.guild, player1.guild);

                        double tempAttackPoint = p1Hero.getAttackPoint();
                        p1Hero.setAttackPoint(tempAttackPoint*0.2);

                        //Bonus attack
                        System.out.println("Highlander's bonus turn");
                        System.out.print(p1Name+"'s "+p1HeroName + " attacks " +p2Name+"'s ");

                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }

                        p1Hero.attack(player2.guild, player1.guild);
                        p1Hero.setAttackPoint(tempAttackPoint);

                    } else {
                        p1Hero.attack(player2.guild, player1.guild);
                    }
                }
                case "Arcane" -> {
                    if (p1Hero.getCharacterType() == "Mystic") {

                        p1Hero.attack(player2.guild, player1.guild);

                        //Heal
                        System.out.println("By Arcane command, the Mystic mends their own wounds!!");
                        double healthIncrement = p1Hero.getHealth()*0.1;
                        p1Hero.setHealth(p1Hero.getHealth() + healthIncrement);

                    } else {
                        p1Hero.attack(player2.guild, player1.guild);
                    }
                }
                default -> {
                    p1Hero.attack(player2.guild, player1.guild);
                }
            }

            // Battle status
            System.out.print("Turn "+i+": ");
            System.out.println(p2Name);
            System.out.print(p2Name+"'s "+p2HeroName+" attacks "+p1Name+"'s ");

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            // player2 attack
            switch (battleLocation) {
                case "Hillcrest" -> {
                    if (p2Hero.getCharacterType() == "Highlander") {

                        //First attack
                        p2Hero.attack(player1.guild, player2.guild);

                        double tempAttackPoint = p2Hero.getAttackPoint();
                        p2Hero.setAttackPoint(tempAttackPoint*0.2);

                        //Bonus attack
                        System.out.println("Highlander's bonus turn");
                        System.out.print(p1Name+"'s "+p1HeroName+" attacks " + p2Name+"'s ");

                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }

                        p2Hero.attack(player1.guild, player2.guild);
                        p2Hero.setAttackPoint(tempAttackPoint);

                    } else {
                        p2Hero.attack(player1.guild, player2.guild);
                    }
                }
                case "Arcane" -> {
                    if (p2Hero.getCharacterType() == "Mystic") {

                        p2Hero.attack(player1.guild, player2.guild);
                        //Heal
                        System.out.println("By Arcane command, the Mystic mends their own wounds!!");
                        double healthIncrement = p2Hero.getHealth()*0.1;
                        p2Hero.setHealth(p2Hero.getHealth() + healthIncrement);

                    } else {
                        p2Hero.attack(player1.guild, player2.guild);
                    }
                }
                default -> {
                    p2Hero.attack(player1.guild, player2.guild);
                }
            }
        }

        // Battle outcome
        int p1Survivors = 0;
        int p2Survivors = 0;
        for(Character c: player1.guild){
            if(c.getHealth() > 0){
                p1Survivors++;
            }
        }
        for(Character c: player2.guild){
            if(c.getHealth() > 0){
                p2Survivors++;
            }
        }

        if (p1Survivors > 0 && p2Survivors == 0){
            updateStatus(player1,player2);
        } else if(p1Survivors == 0 && p2Survivors > 0){
            updateStatus(player2,player1);
        } else {
            System.out.println("Draw");
            System.out.printf("%s XP: %d , Gold Coin: %.2f%n",player1.getName(),player1.getXP(),player1.getGoldCoins());
            System.out.printf("%s XP: %d , Gold Coin: %.2f%n",player2.getName(),player2.getXP(),player2.getGoldCoins());
        }
    }
    public static void updateStatus(UserProfile winner,UserProfile looser) {
        System.out.println(winner.getName() + " Won!!!");

        double reward = looser.getGoldCoins()*0.1;
        winner.setGoldCoins(winner.getGoldCoins() + reward);
        looser.setGoldCoins(looser.getGoldCoins() - reward);

        winner.setXP(winner.getXP() + 1);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        System.out.printf("%s XP: %d , Gold Coin: %.2f%n",winner.getName(),winner.getXP(),winner.getGoldCoins());
        System.out.printf("%s XP: %d , Gold Coin: %.2f%n",looser.getName(),looser.getXP(),looser.getGoldCoins());
    }
    public static void printHeros(){
        System.out.println("                           Mystic Mayhem Heroes                                          ");
        // Archers
        System.out.printf("---Archers---%n");
        System.out.printf("   %-20s | %-5s | %6s | %7s | %6s | %5s |%n","      ","Price","Attack","Defence","Health","Speed");
        System.out.printf("1  %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Shooter","80gc",11,4,6,9);
        System.out.printf("2  %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Ranger","115gc",14,5,8,10);
        System.out.printf("3  %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Sunfire","160gc",15,5,7,14);
        System.out.printf("4  %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Zing","200gc",16,9,11,14);
        System.out.printf("5  %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Saggitarius","230gc",18,7,12,17);

        // Knights
        System.out.printf("---Knights---%n");
        System.out.printf("   %-20s | %-5s | %6s | %7s | %6s | %5s |%n","      ","Price","Attack","Defence","Health","Speed");
        System.out.printf("6  %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Squire","85gc",8,9,7,8);
        System.out.printf("7  %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Cavalier","115gc",10,12,7,10);
        System.out.printf("8  %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Templar","155gc",14,16,12,12);
        System.out.printf("9  %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Zoro","180gc",17,16,13,14);
        System.out.printf("10 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Swiftblade","250gc",18,20,17,13);

        // Mages
        System.out.printf("---Mages---%n");
        System.out.printf("   %-20s | %-5s | %6s | %7s | %6s | %5s |%n","      ","Price","Attack","Defence","Health","Speed");
        System.out.printf("11 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Warlock","100gc",12,7,10,12);
        System.out.printf("12 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Illusionist","120gc",13,8,12,14);
        System.out.printf("13 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Enchanter","160gc",16,10,13,16);
        System.out.printf("14 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Conjurer","195gc",18,15,14,12);
        System.out.printf("15 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Eldritch","270gc",19,17,18,14);

        // Healers
        System.out.printf("---Healers---%n");
        System.out.printf("   %-20s | %-5s | %6s | %7s | %6s | %5s |%n","      ","Price","Attack","Defence","Health","Speed");
        System.out.printf("16 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Soother","95gc",10,8,9,6);
        System.out.printf("17 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Medic","125gc",12,9,10,7);
        System.out.printf("18 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Alchemist","150gc",13,13,13,13);
        System.out.printf("19 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Saint","200gc",16,14,17,9);
        System.out.printf("20 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Lightbringer","260gc",17,15,19,12);

        // Mythical Creatures
        System.out.printf("---Mythical Creatures---%n");
        System.out.printf("   %-20s | %-5s | %6s | %7s | %6s | %5s |%n","      ","Price","Attack","Defence","Health","Speed");
        System.out.printf("21 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Dragon","120gc",12,14,15,8);
        System.out.printf("22 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Basilisk","165gc",15,11,10,12);
        System.out.printf("23 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Hydra","205gc",12,16,15,11);
        System.out.printf("24 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Phoenix","275gc",17,13,17,19);
        System.out.printf("25 %-20s | %-5s | %6d | %7d | %6d | %5d |%n","Pegasus","340gc",14,18,20,20);
    }
    public static void printEquipment(){

        System.out.println("                          Mystic Mayhem Hero's Equipments                                         ");
        System.out.printf("---Armour---%n");
        System.out.printf("   %-20s | %-5s | %6s | %7s | %6s | %5s |%n","      ","Price","Attack","Defence","Health","Speed");
        System.out.printf("1  %-20s | %-5s | %6s | %7s | %6s | %5s |%n","Chainmail","70gc","-","+1","-","-1");
        System.out.printf("2  %-20s | %-5s | %6s | %7s | %6s | %5s |%n","Regalia","105gc","-","+1","-","-");
        System.out.printf("3  %-20s | %-5s | %6s | %7s | %6s | %5s |%n","Fleece","150gc","-","+2","+1","-1");

        System.out.printf("---Artefacts---%n");
        System.out.printf("   %-20s | %-5s | %6s | %7s | %6s | %5s |%n","      ","Price","Attack","Defence","Health","Speed");
        System.out.printf("4  %-20s | %-5s | %6s | %7s | %6s | %5s |%n","Excalibur","150gc","+2","-","-","-");
        System.out.printf("5  %-20s | %-5s | %6s | %7s | %6s | %5s |%n","Amulet","200gc","+1","-1","+1","+1");
        System.out.printf("6  %-20s | %-5s | %6s | %7s | %6s | %5s |%n","Crystal","210gc","+2","+1","-1","-1");
    }

    public static void main(String[] args) {

        UserProfile userTemp = new UserProfile("SlDark","Dark01");
        userTemp.addHero("Shooter");
        userTemp.addHero("Squire");
        userTemp.addHero("Warlock");
        userTemp.addHero("Soother");
        userTemp.addHero("Dragon");
        userTemp.setGoldCoins(20);
        userTemp.setHomeground("Arcane");

        HashMap<Integer, String> heroIndex = new HashMap<>();
        heroIndex.put(1,"Shooter");

        Scanner scan = new Scanner(System.in);

        System.out.println("---------------------------------------------------------------------------------------");
        System.out.println("|                              Mystic Mayhem                                          |");
        System.out.println("---------------------------------------------------------------------------------------");

        System.out.print("Enter your name: ");
        String name =scan.nextLine();

        System.out.print("Enter a username: ");
        String username;
        do{
            username = scan.nextLine();
            if(usernames.contains(username)){
                System.out.println("Username is already taken.");
                System.out.print("Enter a username: ");
            } else {
                usernames.add(username);
                break;
            }
        }while (true);

        clearConsole();
        UserProfile user = new UserProfile(name,username);
        users.add(user);

        System.out.println("---------------------------------------------------------------------------------------");
        System.out.println("|                              Mystic Mayhem                                          |");
        System.out.println("---------------------------------------------------------------------------------------");

        printHeros();
        System.out.println("");

        System.out.println("                                  Guilds              ");
        // set default Army
        System.out.println("Guild[1]-> [Archer:Shooter, Knight:Squire, Mage:Warlock, Healer:Soother, Mythical Creature:Dragon]");
        System.out.println("Cost: 480gc");
        System.out.println("Guild[2]-> [Archer:Shooter, Knight:Squire, Mage:Illusionist, Healer:Soother, Mythical Creature:Dragon]");
        System.out.println("Cost: 500gc");

        System.out.print("Select your guild(1/2): ");
        int guildNumber = scan.nextInt();
        boolean choice1 = true;

        while(choice1){
            if(guildNumber<3 && guildNumber>0){
                choice1=false;
            }
            else{
                System.out.println("You have entered an invalid number. Please enter a valid number.");
                System.out.println("                                  Guilds              ");
                // set default Army
                System.out.println("Guild[1]-> [Archer:Shooter, Knight:Squire, Mage:Warlock, Healer:Soother, Mythical Creature:Dragon]");
                System.out.println("Cost: 480gc");
                System.out.println("Guild[2]-> [Archer:Shooter, Knight:Squire, Mage:Illusionist, Healer:Soother, Mythical Creature:Dragon]");
                System.out.println("Cost: 500gc");

                System.out.print("Select your guild(1/2): ");
                guildNumber = scan.nextInt();
            }
        }

        switch (guildNumber) {
            case 1 -> {
                user.addHero("Shooter");
                user.addHero("Squire");
                user.addHero("Warlock");
                user.addHero("Soother");
                user.addHero("Dragon");
                user.setGoldCoins(20);
            }
            case 2 -> {
                user.addHero("Shooter");
                user.addHero("Squire");
                user.addHero("Illusionist");
                user.addHero("Soother");
                user.addHero("Dragon");
                user.setGoldCoins(0);
            }
        }
        System.out.println("Your guild is Ready!");
        System.out.println();

        selectHomeground(user);
        System.out.printf("Your Home Ground is %s.",user.getHomeground());
        System.out.println();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        clearConsole();
        boolean choice3 = true;
        game: while(choice3){
            System.out.println("---------------------------------------------------------------------------------------");
            System.out.println("|                              Mystic Mayhem                                          |");
            System.out.println("---------------------------------------------------------------------------------------");
            System.out.println();
            System.out.printf("""
                What's Next %s?
                1. Battle
                2. Buy Hero
                3. Sell Hero
                4. Buy Equipment
                5. Rename
                6. Show Heroes
                7. Show Equipments
                8. Show Gold Coins
                9. Exit\n""",user.getUserName());
            System.out.print("(1/2/3/4/5/6/7/8/9) : ");
            int option = scan.nextInt();
            int userChoice=1;
            switch(option){
                case 1:
                    if(user.getGuildSize() == 5){
                        selectHomeground(user);
                        //opponent = searchOpponent();
                        System.out.println("Battle Begins");
                        combat(user,userTemp); //userTemp must be replaced by a human player later
                    }
                    else{
                        System.out.println("Your guild is not full.");
                        System.out.println("To battle your guild must be full.");
                        System.out.println("Please buy remaining heros.");
                        continue game;
                    }
                    break;
                case 2:
                    userChoice = user.buyCharacter();
                    if(userChoice == -1){
                        System.out.println("Something went wrong!!");
                    }
                    else if(userChoice == 0){
                        continue;
                    }
                    break;
                case 3:
                    userChoice = user.sellCharacter();
                    if(userChoice == -1){
                        System.out.println("Something went wrong!!");
                    }
                    else if(userChoice == 0){
                        continue;
                    }
                    break;
                case 4:
                    break;
                case 5:
                    Scanner scanner = new Scanner(System.in);
                    System.out.println();
                    System.out.print("Enter the new name : ");
                    String newName = scanner.nextLine();
                    user.setName(newName);
                    break;
                case 6:
                    printHeros();
                    break;
                case 7:
                    printEquipment();
                    break;
                case 8:
                    System.out.println("Gold Coins : "+user.getGoldCoins());
                    break;
                case 9:
                    System.exit(0);
            }

        }






    }
}
